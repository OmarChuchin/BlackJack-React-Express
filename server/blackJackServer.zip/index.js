const express = require('express');
const cors = require('cors');

const db    = require('./database');
const app   = express();
app.use('*', cors());

app.use(express.json());

//GET METHODS
app.get("/crearPartida",db.createParty);//Checado
app.get("/partida",db.showParty);//Checado
app.get("/err",(req,res)=>{
   res.send("<h1>ERROR 404</h1>");
});
app.get("/connectionTest",(req,res)=>{
    console.log("Recibido");
    res.json({"Connection" : "Successful"});
});
app.get("/unirse-partida",db.joinParty);//Checado
app.get('*',(req, res)=> {
    res.redirect('/err');
});

//POST METHODS
app.post("/pedirCarta",db.getCard);
app.post("/terminarTurno",db.finishTurn);
app.post("/resetParty",db.resetParty);

db.mongoConnect(async ()=>{
    app.listen(8081,()=>{console.log('Servidor en línea')});
});
