function shuffle(array) {
    let currentIndex = array.length, temporaryValue, randomIndex;
  
    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
  
      // Pick a remaining element...
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
  
      // And swap it with the current element.
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }
  
    return array;
}

let party   =   {
    id              :   0,
    turn            :   0,
    numPlayers      :   0,
    score           :   0,
    playing         :   true,
    playingPlayers  :   [],
    deck            :   [],
    houseCards      :   [],
    players         :   [
        // {
        //     playerID    :   "someID",
        //     cards       :   [],
        //     score       :   0,
        //     isFinished  :   false
        // }
    ]
};

const DECKS     = ["H","S","C","D"];
const VALUES    = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
const cardsValues = {
    "A"     : 11,
    "2"     : 2,
    "3"     : 3,
    "4"     : 4,
    "5"     : 5,
    "6"     : 6,
    "7"     : 7,
    "8"     : 8,
    "9"     : 9,
    "10"    : 10,
    "J"     : 10,
    "Q"     : 10,
    "K"     : 10,
}

function createPlayingDeck(){
    let deck = [];

    DECKS.forEach(d=>{
        VALUES.forEach(val=>{
            let card = val+d;
            deck.push(card);
        })
    });
    
    const NUMBER_OF_DECKS = 1;
    
    let playingDeck = [];
    
    for(let i = 0;i<NUMBER_OF_DECKS;i++){
        deck = shuffle(deck);
        playingDeck = playingDeck.concat(deck);
    }

    return playingDeck;
}

function getScore(cards){
    let score = 0;
    let numAces = 0;
    cards.forEach(card=>{
        let valueOfCard = card.charAt(0);
        const hasZero   = card.charAt(1)  === "0";
        if(hasZero){
            valueOfCard = "10";
        }
        score += cardsValues[valueOfCard];
        if(valueOfCard === "A"){
            numAces++;
        }
    });
    while(score>21 && numAces>0){
        numAces--;
        score -= 10;
    }
    return score;
}

function housePlay(game){
    let cards           = game.houseCards,
        score           = getScore(cards),
        deck            = game.deck,
        continuePlaying = true;

    while (score<21 && continuePlaying){
        cards.push(deck.pop());
        score = getScore(cards);
        if(score>17){
            continuePlaying = false;
        }
    }
    game.playing    =   false; 
    game.houseCards =   cards;
    game.score      =   score;
    return cards;
}

function getNewPlayer(){
    return {
        playerID    :   "Player "+Math.floor(Math.random()*100000).toString(16),
        cards       :   [],
        score       :   0,
        isFinished  :   false
    };
}

function createParty(){
    let newParty    = JSON.parse(JSON.stringify(party));
    newParty.deck   = createPlayingDeck();
    newParty.id     = Math.floor(Math.random()*10000).toString(16);
    newParty.houseCards.push(newParty.deck.pop());
    return newParty;
}

module.exports = {createParty,getNewPlayer,housePlay};