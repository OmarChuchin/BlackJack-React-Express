const mongodb       =require('mongodb');
const partyUtils    = require("./party");
const MongoClient   = mongodb.MongoClient;

let _db;

const mongoConnect=callback=>{
    MongoClient.connect('mongodb://localhost:27017/blackJack',{
        useNewUrlParser: true,
        useUnifiedTopology: true
    })
    .then(cliente=>{
        console.log('Conectado');
        _db=cliente.db();
        callback();
        //Consultas
    })
    .catch(err=>{
        console.log(err);
        throw err;
    });
};

//It Works
const getDb=()=>{
    if(_db){
        return _db;
    }
    throw 'Base de datos sin configurar';
};

//It Works
function updateGame(id,data){
    const db = getDb();
    db.collection("Games").updateOne({id : id},{$set : data});
}

//It Works
const resetParty = (req,res) =>{
    const PARTY_ID = req.body.partyID;
    const db = getDb();
    db.collection("Games").find({id : PARTY_ID}).toArray((err,documents)=>{
        if(err){
            console.log("There has been an error");
            res.redirect("/err");
        }
        else{
            if(documents.length < 1){
                res.json({});
            }
            let game = documents[0];
            if(game.playing == false){//si la partida termino
                let newGame     = partyUtils.createParty();
                game.deck       =   newGame.deck; //Reinicio el Deck
                game.playing    =   true;
                //Reset the players
                Object.values(game.players).forEach(player =>{
                    player.cards = [];                  //Reset the cards of the player
                    player.cards.push(game.deck.pop()); //Add a card to the player
                    player.cards.push(game.deck.pop()); //Add a card to the player
                });
                //Reset the cards of the house.
                game.houseCards = [game.deck.pop()];    //Give the one card to the house.
                game.numPlayers = game.players.length;
                game.turn       = 0;                    //Reinicia el turno
                game.score      = 0;                    //Reinicia el marcador de la casa.
                updateGame(PARTY_ID,game);              //update the game in BD.
                res.json({
                    reset   :   true,
                    game    :   game
                });
                return;
            }
            res.json(game);//updating the person that ordered the reset.
        }
    });
};

//Checked
const joinParty = async (req,res)=>{
    const newPlayer = partyUtils.getNewPlayer();
    const PARTY_ID = req.query.id;
    const db = getDb();
    db.collection("Games").find({id : PARTY_ID}).toArray((err,documents)=>{
        if(err){
            console.log("There has been an error");
            res.redirect("/err");
        }
        else{
            if(documents.length < 1){
                res.json({});
            }
            const game = documents[0];
            if(game.numPlayers == 0){
                game.numPlayers++;
                newPlayer.cards.push(game.deck.pop());//add the card to player
                newPlayer.cards.push(game.deck.pop());//add the card to player   
            }
            game.players.push(newPlayer);
            updateGame(PARTY_ID,game);
            res.json(game);
        }
    });
};

//Checked
const createParty = async (req,res) =>{
    let newParty = partyUtils.createParty();
    let db = getDb();
    db.collection('Games').insertOne(newParty).then(result=>{
        const ID_OF_GAME = result.ops[0].id;
        res.json({
            "gameID"    :   ID_OF_GAME,
            "success"   :   true
        });
    });
};

//Checked
const showParty = async (req,res) =>{
    const PARTY_ID = req.query.id;
    const db = getDb();
    db.collection("Games").find({id : PARTY_ID}).toArray((err,documents)=>{
        if(err){
            console.log("There has been an error");
            res.redirect("/err");
        }
        else{
            if(documents.length < 1){
                res.json({});
            }
            res.json(documents[0]);
        }
    });
};

//Checked
const getCard = async (req,res) =>{
    const data = req.body;
    const db = getDb();
    db.collection("Games").find({id : data.partyID}).toArray((err,documents)=>{
        if(err){
            console.log("There has been an error");
            res.redirect("/err");
        }
        else{
            const game = documents[0];
            if(game.turn === data.playerID && game.playing){
                let deck = game.deck;
                const cardToAdd = deck.pop();
                let player = game.players[data.playerID];
                player.cards.push(cardToAdd);
                game.players[data.playerID] = player;
                game.deck = deck;
                updateGame(data.partyID,game);
                res.json(game);
            } else {
                res.json({
                    notYourTurn :   true,
                    game        :   game
                });
            }
        }
    });
};

const finishTurn = (req,res) => {
    const data = req.body;
    const db = getDb();
    db.collection("Games").find({id : data.partyID}).toArray((err,documents)=>{
        if(err){
            console.log("There has been an error");
            res.redirect("/err");
        }
        else{
            const game = documents[0];
            if(game.turn === data.playerID){
                game.turn++;
                let player = game.players[data.playerID];
                player.isFinished = true;
                game.players[data.playerID] = player;
                if(game.turn>=game.numPlayers){
                    partyUtils.housePlay(game);
                }
                updateGame(data.partyID,game);
            }
            res.json(game);
        }
    });
};

// const removePlayer = (req,res) =>{
//     const data = req.body;
//     const db = getDb();
//     db.collection("Games").find({id : data.partyID}).toArray((err,documents)=>{
//         if(err){
//             console.log("There has been an error");
//             res.redirect("/err");
//         }
//         else{
//             if(documents.length>0){
//                 const game = documents[0];
//                 const playerID = data.playerID;
//                 let playersLeft = [];
//                 game.players.forEach(player=>{
//                     if(player.playerID === playerID){
//                         if(player.cards.length === 0){//The user is playing;
//                             game.numPlayers++;
//                         }
//                     } else {
//                         playersLeft.push(player);
//                     }
//                 });
//                 game.players = playersLeft;
//                 updateGame(data.partyID,game);
//                 res.json({deleted : true});
//             } else {
//                 res.json({deleted : false});
//             }
//         }
//     });
// };

module.exports = {mongoConnect,createParty,showParty,
                    getCard,joinParty,resetParty,
                    finishTurn};